'use strict'
const test = require('node:test')
const assert = require('node:assert/strict')
const fs = require('node:fs')
const vm = require('node:vm')
const path = require('node:path')
const crypto = require('node:crypto')
const source = fs.readFileSync(path.join(__dirname, '..', 'index.js'), 'utf8')

function trecho(inicio, fim) {
  const a = source.indexOf(inicio)
  assert.ok(a >= 0, `Trecho não encontrado: ${inicio}`)
  const b = source.indexOf(fim, a)
  assert.ok(b > a, `Fim não encontrado: ${fim}`)
  return source.slice(a, b)
}
function carregarIndo() {
  const codigo = [
    trecho('const COMANDOS_INDO = [', '\n]\n') + '\n]',
    trecho('function ehComandoIndo(', '// Comandos canônicos'),
    'ehComandoIndo'
  ].join('\n')
  const ctx = {
    normalizarTexto: v => String(v || '').normalize('NFD').replace(/[̀-ͯ]/g, '').toLowerCase().trim(),
    obterMensagemRespondida: m => m?.message?.extendedTextMessage?.contextInfo?.stanzaId || null
  }
  return vm.runInNewContext(codigo, ctx)
}
const resposta = { message: { extendedTextMessage: { contextInfo: { stanzaId: 'ABC' } } } }
const solta = { message: { conversation: 'x' } }

test('indo: palavras comuns nunca são aceite, mesmo respondendo mensagem', () => {
  const indo = carregarIndo()
  for (const p of ['tudo', 'todo', 'lindo', 'mundo', 'sendo', 'fundo', 'vindo', 'rindo']) {
    assert.equal(indo(p, resposta), false, p)
    assert.equal(indo(p, solta), false, p)
    assert.equal(indo(p), false, p)
  }
})
test('indo: alias exato funciona sem resposta; variação só como resposta', () => {
  const indo = carregarIndo()
  assert.equal(indo('indo'), true)
  assert.equal(indo('lndo', solta), true)
  assert.equal(indo('indox', solta), false)
  assert.equal(indo('indox', resposta), true)
})

test('telefone do cadastro é normalizado para 55+DDD+número', () => {
  const fn = vm.runInNewContext('(' + trecho('function normalizarTelefoneBR(', '\nfunction iniciarServidorCadastro').trim() + ')')
  assert.equal(fn('(83) 98765-4321'), '5583987654321')
  assert.equal(fn('+55 83 98765-4321'), '5583987654321')
  assert.equal(fn('558398765432'), '558398765432')
  assert.equal(fn('12345678901234'), null)
  assert.equal(fn('8333334444'), '558333334444')
  assert.equal(fn('123'), null)
})

test('backup criptografado: ida e volta, e falha com chave/dados adulterados', () => {
  const codigo = trecho('function cifrarBackup(', '// Lê um arquivo de backup') + '\n({ cifrarBackup, decifrarBackup })'
  const mk = key => vm.runInNewContext(codigo, { crypto, Buffer, CHAVE_BACKUP: key })
  const k1 = crypto.scryptSync('a', 's', 32), k2 = crypto.scryptSync('b', 's', 32)
  const A = mk(k1), B = mk(k2)
  const enc = A.cifrarBackup(Buffer.from('segredo'))
  assert.equal(A.decifrarBackup(enc).toString(), 'segredo')
  assert.throws(() => B.decifrarBackup(enc))
  enc[enc.length - 1] ^= 1
  assert.throws(() => A.decifrarBackup(enc))
})

test('undo por diferença: guarda só chaves alteradas e restaura', () => {
  assert.match(source, /diferenca\[chave\] = anterior\[chave\]/)
  assert.match(source, /if \(!\(chave in anterior\)\) continue/)
  assert.match(source, /LIMITE_UNDO_LISTA = Number\(process\.env\.LIMITE_UNDO_LISTA\) \|\| 100/)
})

test('reconexão: todo identificador temporizador* usado está declarado', () => {
  const usados = new Set(source.match(/\btemporizador[A-Z][A-Za-z]+/g))
  for (const nome of usados) assert.match(source, new RegExp(`(?:let|const|var)\\s+${nome}\\b`), `${nome} não declarado`)
})

test('processo trata unhandledRejection e grava ao encerrar', () => {
  assert.match(source, /process\.on\('unhandledRejection'/)
  assert.match(source, /process\.on\(sinal/)
})

test('servidor de cadastro: HOST, limites e honeypot presentes', () => {
  assert.match(source, /process\.env\.HOST \|\| '0\.0\.0\.0'/)
  assert.match(source, /LIMITE_CORPO_CADASTRO = 6 \* 1024 \* 1024/)
  assert.match(source, /limiteExcedido\(ipCliente, 'envio'/)
  assert.match(source, /d\.website/)
  assert.ok(fs.existsSync(path.join(__dirname, '..', 'cadastro.html')), 'cadastro.html deve estar no pacote')
})

test('IA privada tem limite por usuário e modelo configurável', () => {
  assert.match(source, /function permitirUsoIAPrivada/)
  assert.match(source, /process\.env\.GEMINI_MODEL/)
  assert.ok(!/models\/gemini-3\.8-flash:/.test(source), 'modelo não deve estar fixo na URL')
})
