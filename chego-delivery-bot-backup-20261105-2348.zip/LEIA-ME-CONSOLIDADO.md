# Chegô Delivery — pacote RTCloud com OCR configurável

Este ZIP contém o código do bot e arquivos de exemplo. **Verificado por listagem do arquivo**: não contém `auth/`, `backups/`, `.env`, `chego-chaves-ia.json`, `fila.json`, relatórios nem cadastros.

## OCR de comandas

- O fluxo de leitura usa a API OCR.space em português (`language=por`) e, depois, aplica as regras locais de extração, dicionário e aprendizado de layout.
- Não depende de `tesseract.js`, binário Tesseract ou pacote de idioma instalado no servidor.
- É obrigatório configurar uma chave válida da API OCR.space. Sem chave, o bot informa como configurar e não tenta carregar dependência inexistente.
- Para configurar sem colocar segredo no ZIP: abra uma conversa privada com o bot, envie `configurar ocr` e, na mensagem seguinte, envie a chave. O bot não repete a chave. Use `status ocr` para conferir se ela está cadastrada. Esse status confirma apenas presença da chave; a leitura real depende de chave válida, conectividade e cota disponível na OCR.space.
- Alternativamente, configure `OCRSPACE_API_KEY` no painel de variáveis do RTCloud. Variáveis de ambiente têm prioridade sobre a chave salva pelo comando.

## Escala automática de fim de semana

- Na segunda-feira, a partir das 06h (horário de Patos-PB / America/Fortaleza, independentemente do fuso do servidor), o bot monta e publica a escala do sábado e domingo seguintes no grupo `CHEGÔ ENTREGADORES🚀`.
- A alternância usa a escala efetivamente salva para o fim de semana anterior: quem estava escalado fica fora do próximo; quem não estava entra. A lista antiga fixa de nomes foi removida para não excluir pessoas incorretamente.
- `@entregador Folguista` inclui o entregador em todos os fins de semana.
- `@entregador café com leite` exclui permanentemente o entregador das escalas de fim de semana.
- `Folguista` e `café com leite` são mutuamente exclusivos: sempre prevalece o último comando ADM recebido. Aplicar um remove a classificação anterior.
- `@entregador sem escala` continua funcionando como comando de exclusão permanente equivalente.
- Se o bot não conseguir identificar pessoas disponíveis para alternar, não reutiliza a escala anterior; avisa no grupo e não publica uma escala repetida.

## Requisitos do servidor

- Node.js 20 ou superior (Baileys 7 e `fetch`/`FormData` nativos).
- Instalar dependências a partir de `package-lock.json` com `npm ci`.
- O processo de inicialização é `npm start` (ou `node index.js`).
- O RTCloud precisa permitir saída HTTPS para `api.ocr.space`.

## Implantação segura no RTCloud

1. Faça backup dos arquivos e dos dados persistentes do serviço atual antes de trocar qualquer código.
2. Não apague nem substitua o volume persistente. Preserve `auth/`, `backups/`, `fila.json`, `chego-relatorios-persistentes.json`, `chego-aprendizado-comandas.json` e `chego-chaves-ia.json`.
3. Preserve as variáveis atuais do serviço. Configure `DATA_DIR`, `AUTH_DIR` e `REPORTS_FILE` para diretórios persistentes, conforme o volume do RTCloud.
4. Envie os arquivos deste ZIP para a raiz do projeto no RTCloud, mantendo a estrutura. Não envie `.env` de exemplo como se fosse o `.env` real e não substitua variáveis secretas existentes.
5. Confirme Node.js 20+ e que o provedor executará `npm ci` antes do comando de início `npm start`.
6. Reinicie o serviço somente depois de confirmar o backup, a persistência e as variáveis.
7. Depois que o WhatsApp reconectar, configure a chave OCR.space em privado e envie uma foto de comanda para o teste real.

## Correções incluídas nesta consolidação

- Baileys, Pino e QRCode Terminal fixados nas versões do lockfile original.
- Backup dos dados a cada 3 horas; retenção de 96 snapshots.
- Recuperação de sessão após `loggedOut`/401 com marcador de rejeição e bloqueio de restauração de snapshots antigos até uma nova conexão bem-sucedida.
- Disputa de empresas em 2 minutos pelo minuto de origem, sem segundos e sem extensão por campos legados.
- Lista edita a mensagem atual antes de 10 minutos; após esse prazo, a próxima atualização cria nova mensagem. `Lista` força nova publicação.
- Reconciliação de lista a cada 10 minutos e somente quando o texto visível mudou.
- Escritas idênticas de fila e histórico persistente são ignoradas.
- Pico automático respeita a exceção de um único entregador online.
- Persistência atômica via arquivo temporário e rename.
- OCR sem dependência local ausente: API OCR.space como motor de reconhecimento e pós-processamento local.

## Limites da validação

Foram validados sintaxe JavaScript, testes unitários isolados e integridade do pacote. Não foi possível, neste ambiente, acessar o registry npm nem a API OCR.space; portanto não houve chamada real à API nem leitura de imagem real. Também não houve implantação nem teste de ponta a ponta no RTCloud/WhatsApp. O pacote está preparado para instalação no servidor, mas o OCR só fica operacional após inserir uma chave OCR.space válida e confirmar a primeira leitura real.


## Segurança e operação (revisão de 05/11/2026)

- **Defina `BACKUP_KEY`** no painel do provedor: com ela, backups de sessão e de dados são gravados criptografados (AES-256-GCM, arquivos `.enc`). Sem ela, o bot avisa no log e grava em claro. Guarde a chave fora do volume; sem ela os backups criptografados não restauram. Backups antigos em claro continuam sendo lidos.
- `AUTORESTART=true` no `rtcloud.config`; o processo trata `unhandledRejection`/`uncaughtException` e grava os dados ao receber SIGTERM/SIGINT.
- **Cadastro web** (`/cadastro`): limite de 120 requisições/min e 5 envios/hora por IP, corpo máximo de 6 MB, fotos até 2 MB, campo isca anti-robô, telefone normalizado para 55+DDD+número, deduplicação por telefone e CPF, remoção de foto órfã em caso de falha, `HOST` respeitado. Atrás de proxy, use `TRUST_PROXY=true`. CAPTCHA e HTTPS devem ser feitos no provedor/proxy. CPF e nascimento continuam em texto no `fila.json` (permissão 0600): proteja o volume.
- **IA no privado**: limite por usuário (cadastrado: 10/hora e 30/dia; desconhecido: 3/hora e 6/dia), valores em `IA_LIMITE_HORA`/`IA_LIMITE_DIA`. Modelo em `GEMINI_MODEL` (padrão `gemini-3.8-flash`, **não verificado**: confirme que existe para a sua chave).
- **Comando "indo"**: variações aproximadas (1 edição) só valem quando a mensagem é resposta a outra mensagem; palavras comuns são bloqueadas.
- **Gravação em disco**: `fila.json` agora é compacto, gravado com atraso de 0,4 s por rajada e de forma assíncrona; histórico de desfazer limitado a 100 (`LIMITE_UNDO_LISTA`) e guardado como diferenças. O `fila.json` existente é aproveitado; entradas antigas continuam desfazíveis.
- Testes: `npm test`.
