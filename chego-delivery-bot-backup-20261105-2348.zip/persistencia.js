'use strict'

const fs = require('fs')
const path = require('path')
const crypto = require('crypto')

/**
 * Writes a complete file beside its destination and then atomically renames it.
 * A unique temporary filename prevents collisions between overlapping saves.
 * The destination directory must be on a filesystem that supports rename within
 * the same directory. Errors are deliberately propagated to the caller.
 */
function atomicWriteFile(destination, contents, options = {}) {
  const target = path.resolve(destination)
  const directory = path.dirname(target)
  fs.mkdirSync(directory, { recursive: true })
  const temporary = path.join(
    directory,
    `.${path.basename(target)}.${process.pid}.${Date.now()}.${crypto.randomBytes(6).toString('hex')}.tmp`
  )
  let renamed = false
  try {
    fs.writeFileSync(temporary, contents, {
      encoding: options.encoding || 'utf8',
      mode: options.mode || 0o600,
      flag: 'wx'
    })
    try { fs.chmodSync(temporary, options.mode || 0o600) } catch (_) {}
    fs.renameSync(temporary, target)
    renamed = true
  } finally {
    if (!renamed) {
      try { fs.unlinkSync(temporary) } catch (_) {}
    }
  }
}

async function atomicWriteFileAsync(destination, contents, options = {}) {
  const fsp = fs.promises
  const target = path.resolve(destination)
  const directory = path.dirname(target)
  await fsp.mkdir(directory, { recursive: true })
  const temporary = path.join(directory, `.${path.basename(target)}.${process.pid}.${Date.now()}.${crypto.randomBytes(6).toString('hex')}.tmp`)
  let renamed = false
  try {
    await fsp.writeFile(temporary, contents, { encoding: options.encoding || 'utf8', mode: options.mode || 0o600, flag: 'wx' })
    await fsp.rename(temporary, target)
    renamed = true
  } finally {
    if (!renamed) { try { await fsp.unlink(temporary) } catch (_) {} }
  }
}

module.exports = { atomicWriteFile, atomicWriteFileAsync }
