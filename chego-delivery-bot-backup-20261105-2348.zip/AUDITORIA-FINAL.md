# Auditoria consolidada — Chegô Delivery

## Corrigido nesta consolidação

1. **Sessão WhatsApp:** corrige o ciclo perigoso do 401. O fluxo antigo criava um snapshot regular da sessão imediatamente antes de arquivar a sessão rejeitada; isso podia fazer o próximo boot restaurar exatamente as credenciais recusadas. Agora grava um marcador de rejeição, não gera snapshot restaurável nesse evento e bloqueia restauração antiga até uma conexão bem-sucedida.
2. **Backups:** dados a cada 3 horas; 96 cópias mantidas (até 12 dias). AUTH permanece a cada 12 horas.
3. **Listas:** edita a mensagem atual antes de 10 minutos; na próxima alteração após 10 minutos, cria uma nova mensagem e grava sua referência. `Lista` força publicação nova. Pausas ADM/pico continuam respeitadas. Timer de reconciliação passa a 10 minutos e só executa sincronização quando o texto visível mudou.
4. **Fila e processamento:** a reconciliação pós-mensagem só executa se a assinatura dos campos visíveis da fila/status mudou. Mensagens comuns não alteram a lista não acionam renderização/publicação.
5. **Persistência:** evita regravar `fila.json` e o histórico de relatórios quando o conteúdo não mudou. A gravação continua atômica via `persistencia.js`.
6. **Pico automático:** não ativa automaticamente quando há apenas um entregador online; mantém a regra de encerrar com pelo menos dois entregadores 🟢.
7. **Disputa:** regra fixa de 2 minutos pelo minuto do relógio, sem segundos e sem permitir que `prazo`/`prazoRota` legados prolonguem a disputa. A janela de rota continua separada.
8. **Dependências:** os três pacotes de execução estão fixados e alinhados com as versões já presentes no lockfile original.
9. **Segurança do pacote:** `.env`, AUTH, backups, dados operacionais e arquivos de chaves não são incluídos (verificado na listagem do ZIP).

## Auditoria de regras preservadas

- A configuração de grupos continua limitada aos quatro nomes oficiais; g1 é a lista e g2 é o grupo de pedidos/empresas para cada operação.
- O código mantém a fila ONLINE/ESPERA compartilhada entre g1 e g2 por empresa.
- Relatórios preservam a janela de média de tempo dos últimos 7 dias e os históricos persistentes separados.
- A regra fiscal encontrada no código mantém mínimo de 20 entregas na semana e as janelas de fim de semana 10:00–14:00 e 18:00–22:00; o desconto adicional é calculado conforme um ou dois dias de fim de semana elegíveis, além do percentual do mínimo semanal. Não alterei a regra fiscal.
- Bloqueio automático por taxa está explicitamente desativado no código, mantendo o histórico e o relatório de taxas.
- A escala automática foi ajustada para alternar com base na escala realmente salva do fim de semana anterior e publicar na segunda-feira a partir das 06h no fuso `America/Fortaleza`, sem depender do fuso do servidor. A lista antiga fixa de nomes foi removida. Folguista entra sempre; `café com leite` e `sem escala` excluem permanentemente; entre Folguista e café com leite, o último comando ADM substitui o anterior. Os cálculos de cumprimento e punições não foram alterados.
- OCR foi ajustado para usar OCR.space como motor de reconhecimento, seguido das regras locais de extração e aprendizado de layout. O fallback `tesseract.js` foi removido porque não estava instalado e o RTCloud não garante binário/dados Tesseract. A chave OCR.space é obrigatória e deve ser configurada no painel ou pelo comando privado `configurar ocr`.

## Testes executados

- `node --check index.js`.
- `npm test` (28 testes) — testes isolados para limite de disputa, campos legados, prazo de 10 minutos, backups, bloqueio de restauração após 401, exceção do pico com um online, quatro grupos oficiais, condições de taxa, alternância da escala, exceções de folguista/inclusão manual e reconhecimento do comando café com leite.
- Validação sintática dos JSON de manifesto e lockfile e comparação das dependências raiz.
- Verificação do conteúdo do ZIP para excluir credenciais, AUTH, `.env`, backups e dados operacionais.

## Não testado

Não houve login real no WhatsApp, envio/edição real de mensagem nos grupos, teste de ponta a ponta no RTCloud, execução real da API OCR.space ou OCR local com Tesseract.js. Não instale o pacote diretamente sobre o servidor em funcionamento sem backup e janela de manutenção.


## Revisão de 05/11/2026

Corrigido: typo `temporizadorRestauracionAuth` (quebrava reconexão); "indo" fuzzy; cadastro web (limites, honeypot, telefone, dedupe, foto órfã, HOST, `cadastro.html` incluído); limite de uso da IA privada; histórico de desfazer em diferenças e gravação debounced/compacta; backups criptografados; AUTORESTART; handlers de processo; testes novos (`tests/robustez.test.js`) e `npm test`.

Limites conhecidos: sem teste ponta a ponta (WhatsApp, HTTP do cadastro, OCR); CAPTCHA/HTTPS dependem do provedor; CPF em texto no `fila.json`; modelo Gemini não verificado; o cadastro web não foi exercitado em execução (apenas sintaxe e testes estáticos).
