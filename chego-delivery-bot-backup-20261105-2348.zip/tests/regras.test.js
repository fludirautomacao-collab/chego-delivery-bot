'use strict'
const test = require('node:test')
const assert = require('node:assert/strict')
const fs = require('node:fs')
const vm = require('node:vm')
const path = require('node:path')
const source = fs.readFileSync(path.join(__dirname, '..', 'index.js'), 'utf8')
function loadFunction(name) {
  const match = source.match(new RegExp(`function ${name}\\([\\s\\S]*?\\n}`))
  assert.ok(match, `Função ${name} deve existir`)
  return vm.runInNewContext(`(${match[0]})`)
}

test('disputa libera no minuto da solicitação + 2, ignorando segundos', () => {
  const prazo = loadFunction('prazoDeDisputaAtingido')
  const origem = new Date('2026-11-04T08:42:56-03:00').getTime()
  assert.equal(prazo({ enviadaEm: origem }, new Date('2026-11-04T08:43:59-03:00').getTime()), false)
  assert.equal(prazo({ enviadaEm: origem }, new Date('2026-11-04T08:44:00-03:00').getTime()), true)
})

test('campos de prazo legados não prolongam a disputa', () => {
  const prazo = loadFunction('prazoDeDisputaAtingido')
  const origem = new Date('2026-11-04T08:42:05-03:00').getTime()
  const agora = new Date('2026-11-04T08:44:00-03:00').getTime()
  assert.equal(prazo({ enviadaEm: origem, prazo: agora + 240000, prazoRota: agora + 240000 }, agora), true)
})

test('registro legado sem horário de origem não fica preso', () => {
  const prazo = loadFunction('prazoDeDisputaAtingido')
  assert.equal(prazo({ prazo: Date.now() + 86400000 }, Date.now()), true)
})

test('lista só cria nova após 10 minutos completos', () => {
  const regra = loadFunction('deveCriarNovaListaPorIdade')
  const inicio = 1_000_000
  assert.equal(regra(inicio, inicio + 599_999), false)
  assert.equal(regra(inicio, inicio + 600_000), true)
  assert.equal(regra(0, inicio + 900_000), false)
})

test('intervalo de backup de dados está fixado em 3 horas', () => {
  assert.match(source, /const INTERVALO_BACKUP_DADOS = 3 \* 60 \* 60 \* 1000/)
  assert.match(source, /setInterval\(\(\) => criarBackupDados\(false\), INTERVALO_BACKUP_DADOS\)/)
})

test('recuperação de AUTH bloqueia snapshots após loggedOut', () => {
  assert.match(source, /if \(fs\.existsSync\(MARCADOR_SESSAO_REJEITADA\)\)/)
  assert.match(source, /if \(!authTemArquivos && !fs\.existsSync\(MARCADOR_SESSAO_REJEITADA\)\)/)
  assert.match(source, /fs\.writeFileSync\(MARCADOR_SESSAO_REJEITADA/)
})

test('pico automático preserva exceção de um único entregador online', () => {
  assert.match(source, /onlineAtuais\.length > 1 && entregadoresVerdes\.length === 0/)
})

test('cadastro de grupos contém somente os quatro grupos oficiais', () => {
  for (const nome of [
    'EQUIPE MOTOBOY',
    'SEU DELIVERY PATOS-PB',
    'CHEGÔ ENTREGADORES🚀',
    'CHEGÔ DELIVERY (EMPRESAS)'
  ]) assert.ok(source.includes(nome), `Grupo oficial ausente: ${nome}`)
  assert.match(source, /const EMPRESA_CONFIG = \{[\s\S]*?SEU_DELIVERY:[\s\S]*?CHEGO_DELIVERY:/)
})

test('regras de desconto continuam condicionadas ao mínimo semanal e janelas de fim de semana', () => {
  assert.match(source, /x\.entregas>=20/)
  assert.match(source, /h>=10&&h<14/)
  assert.match(source, /h>=18&&h<22/)
})


test('OCR não carrega dependência Tesseract ausente e exige chave OCR.space', () => {
  assert.doesNotMatch(source, /require\(['"]tesseract\.js['"]\)/)
  assert.match(source, /const chaveOCRConfigurada = !!obterChaveOCRSpace\(\)/)
  assert.match(source, /configurar ocr/)
  assert.match(source, /language', 'por/)
})

test('escala alterna quem foi escalado no fim de semana anterior', () => {
  const deveIncluir = loadFunction('deveIncluirNaEscalaAlternada')
  const base = {
    id: '111@s.whatsapp.net', idGrupo: '111@s.whatsapp.net', nomeNormalizado: 'ana',
    ehFolguista: false, escaladoManualmenteParaEsteFim: false,
    idsEscaladosAntes: new Set(['111@s.whatsapp.net']),
    idsManuaisAnteriores: new Set(), nomesFinaisDaEscalaAnterior: new Set()
  }
  assert.equal(deveIncluir(base), false, 'quem estava na escala anterior deve ficar fora')
  assert.equal(deveIncluir({ ...base, id: '222@s.whatsapp.net', idGrupo: '222@s.whatsapp.net', nomeNormalizado: 'bia' }), true,
    'quem não estava na escala anterior deve entrar')
  assert.equal(deveIncluir({ ...base, ehFolguista: true }), true, 'folguista entra sempre')
  assert.equal(deveIncluir({ ...base, escaladoManualmenteParaEsteFim: true }), true,
    'inclusão manual explícita prevalece para o fim de semana alvo')
})

test('café com leite é comando de escala e usa a mesma exclusão permanente', () => {
  assert.match(source, /const cafeComLeite = \/\\bcafe\\s\+com\\s\+leite\$\//)
  assert.match(source, /const semEscala = \/\\bsem\\s\+escala\$\//)
  assert.match(source, /cafe com leite/)
  assert.match(source, /estadoEmpresa\.folguistasEscala = removerPorIdOuNome\(estadoEmpresa\.folguistasEscala\)/)
  assert.match(source, /estadoEmpresa\.semEscalaPermanente = removerPorIdOuNome\(estadoEmpresa\.semEscalaPermanente\)/)
})

test('escala automática publica na segunda a partir das 06h e não repete escala manual já salva', () => {
  assert.match(source, /if \(agora\.getDay\(\) !== 1 \|\| agora\.getHours\(\) < 6\) return/)
  assert.match(source, /salva\.dataSabado === fim\.chave/)
  assert.match(source, /sabadoAnteriorEscala\(fim\.chave\)/)
  assert.doesNotMatch(source, /NOMES_ESCALADOS_FIM_SEMANA_ANTERIOR/)
})

test('na segunda-feira a escala aponta para o sábado seguinte e usa o sábado anterior como base', () => {
  const proximo = loadFunction('proximoFimDeSemana')
  const anterior = loadFunction('sabadoAnteriorEscala')
  const fim = proximo(new Date(2026, 10, 9, 6, 0, 0))
  assert.equal(fim.chave, '2026-11-14')
  assert.equal(anterior(fim.chave), '2026-11-07')
})

test('horário de publicação da escala usa America/Fortaleza, mesmo com servidor em UTC', () => {
  const converter = loadFunction('obterDataHoraFortalezaEscala')
  const instante = new Date('2026-11-09T09:00:00.000Z') // segunda-feira, 06h em Patos-PB
  const local = converter(instante)
  assert.equal(local.getDay(), 1)
  assert.equal(local.getHours(), 6)
  assert.equal(local.getDate(), 9)
})

test('modo silêncio libera somente os sete comandos operacionais definidos', () => {
  assert.match(source, /const COMANDOS_PERMITIDOS_SILENCIO = new Set\(\[\s*'online', 'offline', 'proximo', 'final', 'livre', 'ocupado', 'lista'/)
  assert.match(source, /return COMANDOS_PERMITIDOS_SILENCIO\.has\(cmd\)/)
  assert.doesNotMatch(source, /COMANDOS_PERMITIDOS_SILENCIO\.has\(cmd\) \|\| Object\.values\(aliasesComandos/)
})

test('Pendência envia somente para os entregadores online da empresa do grupo', () => {
  assert.match(source, /const estadoPendencia = empresas\[chaveEmpresaPendencia\]\?\.estado \|\| estado/)
  assert.match(source, /\(estadoPendencia\.online \|\| \[\]\)/)
  assert.match(source, /const mensagem = 'Entrega pendente'/)
  assert.doesNotMatch(source, /const destinatarios = \[\.\.\.new Set\(Object\.keys\(EMPRESA_CONFIG\)/)
})

test('Suporte envia a mensagem de alta demanda com formatação solicitada', () => {
  assert.match(source, /🚨 \*ALTA DEMANDA\* 🚨\\n\\nEstamos com uma demanda muito alta no momento/)
  assert.match(source, /\*Att\. Administração\*/)
})

test('resposta genérica de comando não reconhecido foi removida', () => {
  assert.doesNotMatch(source, /Não consegui entender exatamente o que você precisa/)
})
